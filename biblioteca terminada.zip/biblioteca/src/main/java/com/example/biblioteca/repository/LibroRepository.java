package com.example.biblioteca.repository;

import com.example.biblioteca.model.Libro;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.ListResourceBundle;

@Repository
public class LibroRepository {

    private List<Libro> libros = new ArrayList<>();

    public Libro saveLibro(Libro nuevo){
        libros.add(nuevo);
        return nuevo;
    }

    public List<Libro> getLibros() {
        return libros;
    }

    public Libro buscarPorId(int id){
        for(Libro libro : libros) {
            if (libro.getId() == id) {
                return libro;
            }
        }
        return null;
    }


    public Libro buscarPorIsbn(String isbn){
        for(Libro libro : libros) {
            if (libro.getIsbn().equals(isbn)) {
                return libro;
            }
        }
        return null;
    }

    public Libro guardar(Libro lib){
        libros.add(lib);
        return lib;

    }

    public Libro actualizar(Libro lib) {
        int id = 0;
        int idPosicion = 0;

        for (int i = 0; i < libros.size(); i++) {
            if (libros.get(i).getId() == lib.getId()){
                id = lib.getId();
                idPosicion = 1;
            }
        }
        //pag 10
        Libro libro1 = new Libro();
        libro1.setId(id);
        libro1.setTitulo(lib.getTitulo());
        libro1.setAutor(libro1.getAutor());
        libro1.setEditorial(lib.getEditorial());
        libro1.setIsbn(lib.getIsbn());
        libro1.setFechaPublicacion(lib.getFechaPublicacion());

        libros.set(idPosicion, libro1);
        return libro1;

    }

    public void eliminar(int id) {
        Libro libro = buscarPorId(id);
        if (libro != null){
            libros.remove(libro);

        }
    }

}
