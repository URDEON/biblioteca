package com.example.biblioteca.service;

import com.example.biblioteca.model.Libro;
import com.example.biblioteca.repository.LibroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;


@Service
public class LibroService {

    @Autowired
    private LibroRepository repository;

    public List<Libro> getLibros() {
        return repository.getLibros();
    }

    public Libro saveLibro(Libro nuevo) {
        return repository.saveLibro(nuevo);
    }

    public Libro getLibroId(int id){
        return repository.buscarPorId(id);
    }

    public Libro updateLibro(Libro libro) {
        return repository.actualizar(libro);

    }

    public String deleteLibro(int id){
        repository.eliminar(id);
        return "Producto eliminado";
    }




}
