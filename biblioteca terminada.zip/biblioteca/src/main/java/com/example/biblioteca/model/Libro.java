package com.example.biblioteca.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Libro {

    private int id;
    private String titulo;
    private String autor;
    private String editorial;
    private String isbn;
    private int fechaPublicacion;


}
